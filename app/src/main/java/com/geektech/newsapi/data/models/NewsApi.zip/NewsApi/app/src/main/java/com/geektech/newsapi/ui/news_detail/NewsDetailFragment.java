package com.geektech.newsapi.ui.news_detail;

import com.geektech.newsapi.base.BaseFragment;
import com.geektech.newsapi.databinding.FragmentNewsDetailBinding;

public class NewsDetailFragment extends BaseFragment<FragmentNewsDetailBinding> {
    @Override
    protected FragmentNewsDetailBinding bind() {
        return FragmentNewsDetailBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initValues() {

    }

    @Override
    protected void setupObservers() {

    }

    @Override
    protected void setupListeners() {

    }

    @Override
    protected void setupViews() {

    }

    @Override
    protected void callRequests() {

    }
}
