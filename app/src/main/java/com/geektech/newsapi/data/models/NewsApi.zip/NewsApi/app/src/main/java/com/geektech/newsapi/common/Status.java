package com.geektech.newsapi.common;

public enum Status {

    SUCCESS,
    ERROR,
    LOADING
}
